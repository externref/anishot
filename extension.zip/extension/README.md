# anishot

chrome extension for customisable screenshots
